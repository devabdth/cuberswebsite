class SpacesHelper:
    def __init__(self):
        pass
